---
name: Official Guidance Editorial
colors:
  surface: '#f6fbf5'
  surface-dim: '#d7dbd6'
  surface-bright: '#f6fbf5'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f0f5f0'
  surface-container: '#ebefea'
  surface-container-high: '#e5e9e4'
  surface-container-highest: '#dfe4df'
  on-surface: '#181d1a'
  on-surface-variant: '#444653'
  inverse-surface: '#2c322e'
  inverse-on-surface: '#edf2ed'
  outline: '#757684'
  outline-variant: '#c4c5d5'
  surface-tint: '#3755c3'
  primary: '#00288e'
  on-primary: '#ffffff'
  primary-container: '#1e40af'
  on-primary-container: '#a8b8ff'
  inverse-primary: '#b8c4ff'
  secondary: '#006a63'
  on-secondary: '#ffffff'
  secondary-container: '#99efe5'
  on-secondary-container: '#006f67'
  tertiary: '#5a2500'
  on-tertiary: '#ffffff'
  tertiary-container: '#7d3600'
  on-tertiary-container: '#ffa673'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dde1ff'
  primary-fixed-dim: '#b8c4ff'
  on-primary-fixed: '#001453'
  on-primary-fixed-variant: '#173bab'
  secondary-fixed: '#9cf2e8'
  secondary-fixed-dim: '#80d5cb'
  on-secondary-fixed: '#00201d'
  on-secondary-fixed-variant: '#00504a'
  tertiary-fixed: '#ffdbca'
  tertiary-fixed-dim: '#ffb68e'
  on-tertiary-fixed: '#331200'
  on-tertiary-fixed-variant: '#763300'
  background: '#f6fbf5'
  on-background: '#181d1a'
  surface-variant: '#dfe4df'
typography:
  headline-xl:
    fontFamily: Source Serif 4
    fontSize: 2.25rem
    fontWeight: '700'
    lineHeight: 2.75rem
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Source Serif 4
    fontSize: 1.75rem
    fontWeight: '700'
    lineHeight: 2.25rem
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Source Serif 4
    fontSize: 1.75rem
    fontWeight: '600'
    lineHeight: 2.25rem
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Source Serif 4
    fontSize: 1.375rem
    fontWeight: '600'
    lineHeight: 1.875rem
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Source Serif 4
    fontSize: 1.25rem
    fontWeight: '600'
    lineHeight: 1.75rem
  body-lg:
    fontFamily: Public Sans
    fontSize: 1.125rem
    fontWeight: '400'
    lineHeight: 1.875rem
  body-md:
    fontFamily: Public Sans
    fontSize: 1rem
    fontWeight: '400'
    lineHeight: 1.65rem
  body-sm:
    fontFamily: Public Sans
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: 1.45rem
  label-lg:
    fontFamily: Public Sans
    fontSize: 1rem
    fontWeight: '600'
    lineHeight: 1.5rem
  label-md:
    fontFamily: Public Sans
    fontSize: 0.875rem
    fontWeight: '600'
    lineHeight: 1.25rem
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Public Sans
    fontSize: 0.75rem
    fontWeight: '700'
    lineHeight: 1rem
    letterSpacing: 0.05em
spacing:
  gutter: 1.5rem
  margin: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

The design system establishes an authoritative, calm, and unmistakably institutional environment for public health advisory interactions. It draws aesthetic and operational discipline from national reference publications, notably the UK Government Digital Service (GOV.UK) and the NHS digital design system.

The core design philosophy is rooted in editorial clarity, accessibility, and constitutional restraint:
- **Tone:** Objective, measured, empathetic yet formal, and unflinchingly direct. It avoids all artificial conversational tropes—no anthropomorphic avatars, no greeting waves, no gamification badges, and no casual colloquialisms.
- **Visual Movement:** Contemporary Institutional Editorial. It pairs structured editorial serif hierarchy for authoritative context with an ultra-legible humanist sans-serif for operational interface elements and conversational dialogues.
- **Sensory Experience:** The UI mimics fine archival bond paper and deep mineral inks. It communicates reliability through layout precision, disciplined whitespace, crisp divider rules, and robust status affordances that leave zero room for ambiguity or misinterpretation.

## Colors

The palette is engineered around high luminance contrast ratios meeting or exceeding WCAG AAA standards for text and functional UI controls.

- **Primary (`#1E40AF` - Deep Institutional Navy):** Used for primary interactive actions, key navigational landmarks, and authoritative anchor elements.
- **Secondary (`#0F766E` - Deep Teal/Verdigris):** Used for verified clinical facts, confirmed guidance sources, and validated references.
- **Tertiary (`#B45309` - Amber Warning):** Used for cautionary health disclaimers, triage escalations, and out-of-scope/referral advisories.
- **Neutral Surface & Ink:**
  - Base canvas: `#FBFBFA` (warm parchment) with secondary layered containers at `#F4F3EE`.
  - Primary text / Dark Ink: `#1F2421` (deep carbon slate).
  - Secondary text / Muted Ink: `#4B5563` (cool charcoal).
  - Borders and structural dividers: `#D6D3CD` and `#E5E4DE`.
  - Refusal/Emergency Alert: `#991B1B` (deep crimson) paired with a `#FEF2F2` background.

## Typography

Typography prioritizes prolonged reading comfort and unambiguous comprehension. 

- **Headlines (`Source Serif 4`):** Delivers academic rigor, official weight, and institutional gravity. Headings are structured with generous margins above and tight relationships to subsequent paragraphs.
- **Body & Labels (`Public Sans`):** Optimized for public-sector clarity, neutral legibility, and high distinction between easily confused glyphs (e.g., uppercase `I`, lowercase `l`, and digit `1`).
- **Reading Rhythm:** Body copy defaults to a generous line-height of 1.65–1.7 to support users processing complex health advice under cognitive stress. Text columns must never exceed 72 characters per line for optimal scanning.

## Layout & Spacing

The layout operates on a centered, reading-first fixed column structure embedded within a responsive canvas.

- **Grid Architecture:** Desktop views maintain a strict 680px to 800px conversational reading column centered inside a max-width container of 1140px. Peripheral areas accommodate source citations, navigational breadcrumbs, and emergency triage quick-actions.
- **Breakpoints:**
  - `Desktop (>= 1024px)`: Fixed-center consultation lane, persistent side panel for authoritative sources and contact references.
  - `Tablet (768px - 1023px)`: Single-column layout with 2rem horizontal margins; secondary panels fold into top-level accordions.
  - `Mobile (< 768px)`: Edge-to-edge flow with 1rem margins and full-width input dock.
- **Rhythm:** Spacing follows an 8px modular baseline. Conversational exchanges are separated by `space-xl`, while related citations within an answer use `space-sm` to maintain strict contextual hierarchy.

## Elevation & Depth

Visual hierarchy is maintained purely through architectural borders, surface shifts, and high-contrast lines. Shadows, blurs, and skeuomorphic simulations are intentionally omitted.

- **Surface Tiers:** Layering relies on subtle contrast between the canvas (`#FBFBFA`) and document cards (`#FFFFFF` or `#F4F3EE`).
- **Outlines and Dividers:** Content modules are compartmentalized using sharp 1px borders (`#D6D3CD`). Prominent sections, such as official disclaimers or callouts, use thick 4px solid borders on the left axis.
- **Elevation Metaphor:** Rather than floating above the canvas, interface surfaces are treated as physical sheets resting flat on a reference desk.
- **Accessibility Focus Affordance:** Interactive elements receive a mandatory 3px solid focus ring in primary blue (`#1E40AF`) with a 2px offset (`#FFFFFF`), ensuring instantaneous keyboard navigation visibility.

## Shapes

The design system employs a strict `0` (Sharp) shape language. All corners—including cards, message containers, input controls, action triggers, and badges—are squared at 0px radius.

This choice reinforces the architectural, non-frivolous character of government gazettes and statutory documentation. The sharp edges signal institutional discipline and differentiate the interface from playful commercial conversational apps.

## Components

### Buttons
- **Primary:** Solid `#1E40AF` fill with `#FFFFFF` text, bold `label-md` weight, 0px border-radius, padded at `0.75rem 1.5rem`. A 2px solid bottom accent in `#172554` provides tactile definition.
- **Secondary:** Transparent background with a 1.5px solid border in `#1F2421`, text in `#1F2421`.
- **Destructive/Emergency:** Solid `#991B1B` fill with `#FFFFFF` text for immediate triage routing (e.g., "Contact Emergency Services").
- **States:** Hover introduces an ink shift; focus triggers the standard 3px offset ring. No bouncy spring animations.

### Message Containers (Turn-by-Turn Guidance)
- **User Query:** Displayed in a compact box with a `#F4F3EE` background and a 1px border (`#D6D3CD`), aligned with an explicit bold "Question" label.
- **Chatbot / Official Response:** Rendered on a pure white `#FFFFFF` surface with a 1px solid border (`#D6D3CD`) and an optional 4px left border in `#1E40AF`. Responses are formatted with editorial markdown—headings, bulleted guidance, and citation references. Avatars and speech bubble tails are forbidden.

### Status Badges & Notice Panels
- **Out-of-Scope / Clinical Refusal:** Rendered as a prominent panel with a 4px left border in `#991B1B`, background in `#FEF2F2`, and dark crimson text. It clearly states the system's operational scope and provides immediate official referral alternatives.
- **Advisory / Disclaimer:** Left border in `#B45309`, background `#FFFBEB`.
- **Badges:** All-caps `label-sm` monospace-style labels with sharp borders and muted fills (e.g., `[OFFICIAL GUIDANCE]`, `[TRIAGE NOTICE]`).

### Input Fields & Search Bars
- Rectangular 1px solid `#1F2421` borders on `#FFFFFF` backgrounds.
- Padding of `1rem`. Active input retains high-contrast text with zero floating or disappearing placeholder text.
- Keyboard focus produces the global 3px solid focus outline with 2px separation.

### Checkboxes & Radio Controls
- Square 20x20px interactive targets with high-contrast check marks.
- Labels are styled in `body-md` with generous click targets extending across the full row.

### Citation & Reference Cards
- Inline footnotes and reference cards embedded at the bottom of guidance answers.
- Displayed with a 1px dashed or solid border (`#D6D3CD`), identifying the specific publication, issuing authority (e.g., "Department of Health"), and date of last clinical review.