---
name: Clinical Dietary Editorial
colors:
  surface: '#f7f9ff'
  surface-dim: '#d4dbe5'
  surface-bright: '#f7f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#edf4fe'
  surface-container: '#e8eef9'
  surface-container-high: '#e2e9f3'
  surface-container-highest: '#dce3ed'
  on-surface: '#151c23'
  on-surface-variant: '#44474d'
  inverse-surface: '#2a3139'
  inverse-on-surface: '#ebf1fc'
  outline: '#75777d'
  outline-variant: '#c5c6cd'
  surface-tint: '#515f76'
  primary: '#101f33'
  on-primary: '#ffffff'
  primary-container: '#263449'
  on-primary-container: '#8e9cb6'
  inverse-primary: '#b9c7e2'
  secondary: '#525f74'
  on-secondary: '#ffffff'
  secondary-container: '#d6e3fc'
  on-secondary-container: '#58657a'
  tertiary: '#3d0e01'
  on-tertiary: '#ffffff'
  tertiary-container: '#592310'
  on-tertiary-container: '#d7886d'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d5e3ff'
  primary-fixed-dim: '#b9c7e2'
  on-primary-fixed: '#0d1c30'
  on-primary-fixed-variant: '#39475d'
  secondary-fixed: '#d6e3fc'
  secondary-fixed-dim: '#bac7df'
  on-secondary-fixed: '#0e1c2e'
  on-secondary-fixed-variant: '#3a475b'
  tertiary-fixed: '#ffdbd0'
  tertiary-fixed-dim: '#ffb59d'
  on-tertiary-fixed: '#390c00'
  on-tertiary-fixed-variant: '#713621'
  background: '#f7f9ff'
  on-background: '#151c23'
  surface-variant: '#dce3ed'
typography:
  display:
    fontFamily: Newsreader
    fontSize: 48px
    fontWeight: '400'
    lineHeight: 56px
    letterSpacing: -0.02em
  display-mobile:
    fontFamily: Newsreader
    fontSize: 36px
    fontWeight: '400'
    lineHeight: 44px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Newsreader
    fontSize: 36px
    fontWeight: '400'
    lineHeight: 44px
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Newsreader
    fontSize: 28px
    fontWeight: '400'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Newsreader
    fontSize: 26px
    fontWeight: '400'
    lineHeight: 34px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Newsreader
    fontSize: 20px
    fontWeight: '500'
    lineHeight: 28px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 3rem
  margin-tablet: 2rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system embodies an editorial, evidence-based wellness aesthetic tailored for clinical dietary guidance. The interface balances academic rigor with warm hospitality, actively rejecting stereotypical wellness tropes like leaf motifs, neon greens, and airy pastels.

The target audience comprises health-conscious individuals, patients managing specific nutritional regimens, and practitioners seeking clear, authoritative guidance. The visual tone evokes trust, quiet confidence, and thoughtful contemplation—drawing inspiration from contemporary nutritional journals and high-end culinary publications.

The design movement combines **Minimalism** with **Editorial Precision**: generous whitespace, disciplined typographic contrast, warm low-contrast surfaces, and subtle hairline structure rather than heavy elevation.

## Colors

The palette establishes an intellectual, human-centered foundation rooted in warm ivory, deep ink navy, and sun-baked terracotta accents.

- **Primary (`#263449`)**: Deep navy ink, used for high-emphasis typography, primary buttons, structural lines, and core brand indicators.
- **Secondary (`#435064`)**: Soft slate navy, utilized for secondary text, active state treatments, and subdued iconography.
- **Tertiary (`#B86E55`)**: Muted terracotta, functioning as an intentional focal accent for critical callouts, key active indicators, dietary highlights, and micro-interactions.
- **Pale Terracotta (`#F3E6DF`)**: Soft tinted background for alerts, nutritional badges, and active toggle surfaces.
- **Canvas (`#F7F4EF`)**: Warm ivory foundation serving as the primary page background.
- **Surface (`#FFFDFA`)**: Off-white tone for cards, modal sheets, and layered containers.
- **Mist Blue (`#E8ECF0`)**: Low-contrast secondary fill for table headers, informational blocks, and subtle segment controls.
- **Borders (`#E4DFD6`)**: Muted parchment hairline divider used to articulate space without jarring contrast.
- **Muted Text (`#737A83`)**: Balanced neutral for supporting captions, metadata, and placeholder copy.

## Typography

The type scale balances academic credibility with effortless scannability:

- **Headlines (`Newsreader`)**: Evokes the credibility of medical journals and literary publications. Headings use optical sizing with relaxed, natural rhythm. Key editorial pull quotes and nutrient highlights leverage italic styles sparingly.
- **Body & Labels (`Plus Jakarta Sans`)**: Delivers geometric clarity and legibility across dense nutritional values, macronutrient compositions, and ingredient breakdowns.
- **Numbers & Metrics**: Tabular figures should be enabled for all data-dense displays (e.g., nutrient grams, caloric counts) to maintain visual vertical alignment across tables and charts.

## Layout & Spacing

The layout is grounded in a structured, publication-grade fluid grid with strict upper-bound limits for comfortable reading lengths:

- **Grid Architecture**: 12-column layout on desktop (max width 1200px for content; 760px for long-form guidance prose), collapsing to an 8-column layout on tablet, and a 4-column layout on mobile.
- **Margins & Gutters**: Generous margins frame the page like an open book. Desktop margins (`3rem`) create breathing space, scaling down to `1.25rem` on mobile.
- **Rhythm**: Spacing follows an intentional 4px/8px scale. Dense nutrition panels prioritize `space-xs` and `space-sm` for unified data clumps, whereas editorial recommendations use `space-lg` and `space-xl` to segment guidance modules cleanly.

## Elevation & Depth

This design system avoids traditional dropped shadows in favor of **Tonal Layers** and **Low-Contrast Hairlines**:

- **Layering**: Depth is achieved through surface contrasts: the base page sits at `#F7F4EF`, elevated panels and cards shift forward to `#FFFDFA`, and inset secondary widgets occupy `#E8ECF0` or `#F3E6DF`.
- **Borders over Shadows**: Spatial containment is articulated through a single continuous 1px hairline border (`#E4DFD6`).
- **Elevated Modals & Overlays**: When spatial detachment is mandatory (e.g., dietary filter sheets or floating actions), use an ultra-diffused, ambient shadow: `0 12px 32px -4px rgba(38, 52, 73, 0.06)`, tinted exclusively with the primary navy rather than true black.

## Shapes

The design uses a **Soft** shape language (`roundedness: 1`), conveying structured medical precision without becoming cold or sterile.

- **Base Radius (0.25rem / 4px)**: Inputs, small buttons, tags, and data cells.
- **Medium Radius (0.5rem / 8px)**: Standard cards, guidance modules, meal planning containers, and dialog panels.
- **Large Radius (0.75rem / 12px)**: Outer structural overlays, bottom sheets, and hero recommendation surfaces.
- **Full Pill (`9999px`)**: Reserved exclusively for status indicators, micronutrient pills, and dietary category chips.

## Components

### Buttons
- **Primary**: Background `#263449`, text `#FFFDFA`, 0.25rem border radius. Hover transitions to `#435064`.
- **Secondary**: Outlined with 1px `#E4DFD6`, background `#FFFDFA`, text `#263449`. Hover initiates a subtle wash of `#E8ECF0`.
- **Tertiary Accent**: Background `#B86E55`, text `#FFFDFA`. Reserved for direct dietary actions (e.g., "Log Meal", "Accept Protocol"). Hover transitions to `#A25E47`.

### Chips & Dietary Badges
- Pill-shaped (`rounded-full`) with uppercase or title-case text in `label-sm`.
- **Allergen / Warning**: `#F3E6DF` background, `#B86E55` text, hairline border in `#E4DFD6`.
- **Category Filter**: `#FFFDFA` background, `#737A83` text, hairline border in `#E4DFD6`. Active state shifts to `#263449` fill with `#FFFDFA` text.

### Cards & Guidance Modules
- Background `#FFFDFA`, enclosed by a 1px solid `#E4DFD6` border, with 0.5rem roundedness.
- Padding set to `space-lg` on desktop, `space-md` on mobile. No drop shadows.
- Distinct recommendation tiers feature a left accent border (3px solid `#B86E55`).

### Inputs & Selectors
- Background `#FFFDFA`, 1px solid border `#E4DFD6`, border radius 0.25rem.
- Height: 44px for standard inputs; text styled with `body-md` in `#263449`.
- Focus ring: 1px border shift to `#263449` accompanied by a 2px offset glow in `rgba(38, 52, 73, 0.12)`.

### Checkboxes & Radios
- Checkbox: 18px square with 2px radius. Inactive: `#FFFDFA` background, `#E4DFD6` border. Active: `#263449` background with `#FFFDFA` checkmark.
- Radio: 18px circle, matching border dynamics with a 6px central solid dot when checked.

### Lists & Nutritional Breakdowns
- Key-value metric rows separated by 1px horizontal borders in `#E4DFD6`.
- Metric labels in `body-sm` (`#737A83`), metric numerical values aligned right using `label-md` (`#263449`) with tabular numeric spacing.

### Guidance Note Callouts
- Full-width callout banners featuring a `#F3E6DF` surface, 0.5rem radius, and a 1px border in `#B86E55`. Body text leverages `body-sm` with highlighted clinical terms rendered in `label-md` (`#B86E55`).